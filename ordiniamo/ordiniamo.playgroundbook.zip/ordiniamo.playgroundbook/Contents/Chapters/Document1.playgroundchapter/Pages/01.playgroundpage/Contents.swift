
//#-hidden-code
//  Contents.swift
//
//  Copyright (c) 2017 GiovannaBusconi. All Rights Reserved.
//


//: A UIKit based Playground for presenting user interface

import UIKit
import PlaygroundSupport

class MyViewController : UIViewController {
    override func loadView()
    {
        let view = UIView()
        view.backgroundColor = .green
        
        let label = UILabel()
        label.frame = CGRect(x: 50, y: 50, width: 200, height: 15)
        label.text = "Vettore da ordinare"
        label.textColor = .black
        view.addSubview(label)
        
       
        var valoriVett = [UILabel]()
       // var valore : Int
        var array1D = [Int]()
        
        for i in 0...9
        {
            array1D.append(Int(arc4random()) % 100)
            valoriVett.append(UILabel())
            valoriVett[i].text = "\(array1D[i])"
            valoriVett[i].textColor = .black
            valoriVett[i].frame = CGRect(x: 100, y: 80+(i+1)*30, width: 200, height: 15)
            view.addSubview(valoriVett[i])
            
        }
        
        self.view = view
 

//#-end-hidden-code

/*:
 # Ordiniamo
 
 Con una funzione che genera numeri casuali, è stato inizializzato un vettore di 10 elementi.
 
 
 Il nome del vettore è array1D, la sua dichiarazione
 
 `var array1D = [Int]()`
 
 Scrivi il codice che ordina questo vettore utilizzando il metodo bubble sort illustrato nell'introduzione.
 */

//#-editable-code Inserisci qui il tuo codice
        // scrivi qui il tuo codice
        
        

//#-end-editable-code
        
        
//: [Previous](@previous)  ||  [Next Topic](@next)
        
        
//#-hidden-code

let label1 = UILabel()
label1.frame = CGRect(x: 300, y: 50, width: 200, height: 15)
label1.text = "Vettore ordinato"
label1.textColor = .black
view.addSubview(label1)

var valoriVettOrdinato = [UILabel]()
// var valore : Int

//controllo ordine
        
var flag = 1
        for i in 0...8 {
            if (array1D[i]>array1D[i+1]) {
                flag = 0
            }
        }
        
        let labelA = UILabel()
        labelA.frame = CGRect(x: 50, y: 490, width: 500, height: 20)
        if (flag == 1) {labelA.text = "OTTIMO!!! Bel lavoro!!!!"} else {labelA.text = "Controlla l'ordinamento NON è corretto!"}
        labelA.textColor = .green
        labelA.backgroundColor = .black
        view.addSubview(labelA)
    
for i in 0...9
{
    valoriVettOrdinato.append(UILabel())
    valoriVettOrdinato[i].text = "\(array1D[i])"
    valoriVettOrdinato[i].textColor = .black
    valoriVettOrdinato[i].frame = CGRect(x: 350, y: 80+(i+1)*30, width: 200, height: 15)
    view.addSubview(valoriVettOrdinato[i])
    
}

self.view = view
}
}
// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()
//#-end-hidden-code



//#-hidden-code
//
//  main.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//
//#-end-hidden-code
//#-code-completion(module, hide, Swift)
//#-code-completion(identifier, hide, AbstractDrawable, _ColorLiteralType, _setup())
//#-hidden-code
_setup()
//#-end-hidden-code
// Esaminiamo alcuni comandi che ci ti saranno utili per creare "ilTuoMondrian" 
//#-editable-code Tap to enter code
//#-localizable-zone(createk1)
// 1. Create a circle
//#-end-localizable-zone
let circle = Circle(radius: 3)
circle.center.y += 19

//#-localizable-zone(createk2)
// 2. Create a rectangle
//#-end-localizable-zone
let rectangle = Rectangle(width: 10, height: 5, cornerRadius: 0.75)
rectangle.color = .red
rectangle.center.y += 12

//#-localizable-zone(createk3)
// 3. Create a line
//#-end-localizable-zone
let line = Line(start: Point(x: -10, y: 9), end: Point(x: 10, y: 9), thickness: 0.5)
line.center.y -= 3
line.rotation = 170 * (Double.pi / 180)
line.color = .yellow

//#-localizable-zone(createk4)
// 4. Create text
//#-end-localizable-zone
let text = Text(string: "/*#-localizable-zone(helloWorldText)*/Hello world!/*#-end-localizable-zone*/", fontSize: 32.0, fontName: "Futura")
text.center.y -= 0


//#-end-editable-code

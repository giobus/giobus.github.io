//#-hidden-code
//
//  main.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//
//#-end-hidden-code
//#-code-completion(module, hide, Swift)
//#-code-completion(identifier, hide, AbstractDrawable, _ColorLiteralType, _setup())
//#-hidden-code
_setup()
func ilMioMondrian() {

var  rettangolo = Rectangle(width: 70, height: 70, cornerRadius: 0)
rettangolo.color = .white

var linea = Line(start: Point(x: -35, y: 30), end: Point(x: 25, y: 30), thickness: 0.5)
linea.color = .black
linea = Line(start: Point(x: 25, y: 35), end: Point(x: 25, y: -35), thickness: 0.5)
linea.color = .black
linea = Line(start: Point(x: 10, y: 35), end: Point(x: 10, y: -35), thickness: 0.5)
linea.color = .black
linea = Line(start: Point(x: -27, y: 30), end: Point(x: -27, y: -35), thickness: 0.5)
linea.color = .black
linea = Line(start: Point(x: -35, y: 15), end: Point(x: -27, y: 15), thickness: 0.5)
linea.color = .black
linea = Line(start: Point(x: 10, y: 15), end: Point(x: 25, y: 15), thickness: 0.5)
linea.color = .black
linea = Line(start: Point(x: -27, y: -5), end: Point(x: 25, y: -5), thickness: 0.5)
linea.color = .black
linea = Line(start: Point(x: -5, y: -28), end: Point(x: 25, y: -28), thickness: 0.5)
linea.color = .black
linea = Line(start: Point(x: -27, y: -20), end: Point(x: 10, y: -20), thickness: 0.5)
linea.color = .black
linea = Line(start: Point(x: -35, y: -15), end: Point(x: 35, y: -15), thickness: 0.5)
linea.color = .black
linea = Line(start: Point(x: -5, y: -5), end: Point(x: -5, y: -35), thickness: 0.5)
linea.color = .black
linea = Line(start: Point(x: 17.5, y: 15), end: Point(x: 17.5, y: -5), thickness: 0.5)
linea.color = .black

linea = Line(start: Point(x: -22, y: 30), end: Point(x: -22, y: 35), thickness: 0.5)
linea.color = .black

rettangolo = Rectangle(width: 36.5, height: 34.5, cornerRadius: 0)
rettangolo.color = .red
rettangolo.center.x -= 8.5
rettangolo.center.y += 12.5

rettangolo = Rectangle(width: 21.5, height: 14.5, cornerRadius: 0)
rettangolo.color = .black
rettangolo.center.x -= 16
rettangolo.center.y += -12.5

rettangolo = Rectangle(width: 15, height: 8, cornerRadius: 0)
rettangolo.color = .black
rettangolo.center.x += 2.5
rettangolo.center.y -= 24

rettangolo = Rectangle(width: 14.5, height: 12.5, cornerRadius: 0)
rettangolo.color = .init(_colorLiteralRed: 0, green: 0, blue: 1, alpha: 1)
rettangolo.center.x += 17.5
rettangolo.center.y -= 21.5

rettangolo = Rectangle(width: 10, height: 20, cornerRadius: 0)
rettangolo.color = .red
rettangolo.center.x += 30.25
rettangolo.center.y -= 25.25

rettangolo = Rectangle(width: 7.9, height: 19.9, cornerRadius: 0)
rettangolo.color = .yellow
rettangolo.center.x -= 31.2
rettangolo.center.y -= 25.2

rettangolo = Rectangle(width: 14.5, height: 14.5, cornerRadius: 0)
rettangolo.color = .yellow
rettangolo.center.x += 17.5
rettangolo.center.y += 22.5

rettangolo = Rectangle(width: 14.5, height: 4.8, cornerRadius: 0)
rettangolo.color = .yellow
rettangolo.center.x += 17.5
rettangolo.center.y += 32.65

rettangolo = Rectangle(width: 29.5, height: 7, cornerRadius: 0)
rettangolo.color =  .init(_colorLiteralRed: 0.2, green: 0.2, blue: 0.2, alpha: 0.3)
rettangolo.center.x += 10
rettangolo.center.y -= 31.75

rettangolo = Rectangle(width: 8, height: 29.75, cornerRadius: 0)
rettangolo.color =  .init(_colorLiteralRed: 0.2, green: 0.2, blue: 0.2, alpha: 0.3)
rettangolo.center.x -= 31.25
rettangolo.center.y -= 0

rettangolo = Rectangle(width: 10, height: 50, cornerRadius: 0)
rettangolo.color =  .init(_colorLiteralRed: 0.2, green: 0.2, blue: 0.2, alpha: 0.3)
rettangolo.center.x += 30.25
rettangolo.center.y += 10

rettangolo = Rectangle(width: 13, height: 5, cornerRadius: 0)
rettangolo.color =  .init(_colorLiteralRed: 0.2, green: 0.2, blue: 0.2, alpha: 0.3)
rettangolo.center.x -= 28.75
rettangolo.center.y += 32.75

rettangolo = Rectangle(width: 14.5, height: 9.5, cornerRadius: 0)
rettangolo.color =  .init(_colorLiteralRed: 0.2, green: 0.2, blue: 0.2, alpha: 0.3)
rettangolo.center.x += 2.5
rettangolo.center.y -= 10

rettangolo = Rectangle(width: 14.5, height: 4.5, cornerRadius: 0)
rettangolo.color = .init(_colorLiteralRed: 0.2, green: 0.2, blue: 0.2, alpha: 0.3)
rettangolo.center.x += 2.5
rettangolo.center.y -= 17.5


}

//#-end-hidden-code
//#-editable-code Tap to enter code
// Prova a eseguire la funzione ilMioMondrian() e vedi cosa accade ...


ilMioMondrian()


//#-end-editable-code

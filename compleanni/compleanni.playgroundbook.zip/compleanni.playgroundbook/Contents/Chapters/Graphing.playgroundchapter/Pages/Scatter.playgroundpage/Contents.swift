//#-code-completion(module, hide, Swift)
//#-code-completion(identifier, hide, _setup())
//#-code-completion(identifier, hide, AbstractPointChartable)
//#-hidden-code
_setup()

//  Contents.swift
//
//  Copyright (c) 2019 GiovannaBusconi. All Rights Reserved.
//


//: A UIKit based Playground for presenting user interface

import UIKit
import PlaygroundSupport

class MyViewController : UIViewController {
    override func loadView()
    {
        let view = UIView()
        view.backgroundColor = .red
        
        self.view = view
        
        
        //#-end-hidden-code
        
        /*
     
     
         
         Evidentemente la probabilità di trovare in un gruppo due persone che compiono gli anni lo stesso giorno è più di quanto ci si potesse aspettare!!!!
         
         Sareste in grado di calcolare quante persone devono essere riunite per avere una probabilità del 97% di trovarne due con lo stesso compleanno?
         
        Calcolalo e assegnalo alla variabile num.
         
         */
        
        var num = 0  // dichiarazione e inizializzazione variabile num
        //#-editable-code Inserisci qui il tuo codice
        // scrivi qui il tuo codice
        
       
        
        
        
        
        
        
        
        
        
        //#-end-editable-code
        //#-hidden-code
        
        
        
        //: [Previous](@previous)  ||  [Next Topic](@next)
        
        
        
        
        let label = UILabel()
        label.frame = CGRect(x: 50, y: 50, width: 300, height: 40)
        label.text = "          La probabilità sarà del 97% con"
        label.backgroundColor = .white
        label.textColor = .black
        view.addSubview(label)
        
        let label1 = UILabel()
        label1.frame = CGRect(x: 100, y: 100, width: 200, height: 40)
        label1.text = "    " + String(num) + "  persone"
        label1.backgroundColor = .white
        label1.textColor = .black
        view.addSubview(label1)
        
        let labeli = UILabel()
        labeli.frame = CGRect(x:0, y: 170, width: 500, height: 1)
        labeli.backgroundColor = .white
        view.addSubview(labeli)
        
        if (num == 50 )
        {
            let label4 = UILabel()
            label4.frame = CGRect(x: 100, y: 250, width: 200, height: 40)
            label4.text = "    Ottimo lavoro!!!"
            label4.backgroundColor = .yellow
            label4.textColor = .black
            view.addSubview(label4)
        } else {
            let label5 = UILabel()
            label5.frame = CGRect(x: 100, y: 250, width: 200, height: 40)
            label5.text = "     Controlla meglio ..."
            label5.backgroundColor = .yellow
            label5.textColor = .black
            view.addSubview(label5)
        }
        
        self.view = view
    }
}
// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()
//#-end-hidden-code


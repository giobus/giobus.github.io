//#-code-completion(module, hide, Swift)
//#-code-completion(identifier, hide, _setup())
//#-code-completion(identifier, hide, AbstractPointChartable)
//#-hidden-code
_setup()
//#-end-hidden-code
//#-editable-code Tap to enter code.
/*
 #Compleanni
 
 E' interessante vedere come aumenta la probabilità di trovare in un gruppo, due persone con lo stesso compleanno in relazione alla numerosità del gruppo stesso.
 
 Scrivete un programma che visualizzi un grafico in un piano cartesiano che raffiguri tale andamento.
 
 In ascissa inserisci i numeri da 0 a 366 che rappresentano la numerosità delle persone; arriva fino a 366 perchè dopo tale valore la probabilità sarà sempre uguale a 1!
 In ordinata, invece, riporta i valori della probabilità di trovare due persone con lo stesso compleanno in un gruppo di x persone.
 
 Per costruire tale grafico devi creare un vettore di coordinate, utilizzando la seguente diuchiarazione
 
     |  let data = XYData()
 
 in cui memorizzare i valori necessari per costruire il grafico.
 
 Dopo basterà inizializzare una variabile di tipo LinePlot con il vettore di tipo xyData.
 
    |  let lineFromDataSet = LinePlot(xyData: data)
 
 Per scegliere il colore della linea si utilizzerà il metodo .color
 
 */
var prob = 1.0


var array1D = [Double]()
array1D.append(0.0)
array1D.append(0.0)
for i in 2...366
{
    prob = 1.0
    for j in 1...i {
        prob = prob * ((365.0 - Double (j))/365.0)
    }
    prob = 1.0 - prob
    array1D.append(prob)
}


let data = XYData()
for i in 0...366 {
    data.append(x: Double(i), y: array1D[i])
}
let lineFromDataSet = LinePlot(xyData: data)
lineFromDataSet.color = #colorLiteral(red: 0.07005243003, green: 0.5545874834, blue: 0.1694306433, alpha: 1)

//#-end-editable-code

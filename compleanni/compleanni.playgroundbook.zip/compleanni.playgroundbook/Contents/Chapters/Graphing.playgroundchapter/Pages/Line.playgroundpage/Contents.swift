//#-code-completion(module, hide, Swift)
//#-code-completion(identifier, hide, _setup())
//#-code-completion(identifier, hide, AbstractPointChartable)
//#-hidden-code
_setup()
//#-end-hidden-code

/*
 
 E' interessante vedere come aumenta la probabilità di trovare in un gruppo, due persone con lo stesso compleanno in relazione alla numerosità del gruppo stesso.
 
 Scrivete un programma che visualizzi un grafico in un piano cartesiano che raffiguri tale andamento.
 
 In ascissa inserisci i numeri da 0 a 366 che rappresentano la numerosità delle persone; arriva fino a 366 perchè dopo tale valore la probabilità sarà sempre uguale a 1!
 In ordinata, invece, riporta i valori della probabilità di trovare due persone con lo stesso compleanno in un gruppo di x persone.
 
 Per costruire tale grafico devi creare un vettore di coordinate, utilizzando la seguente diuchiarazione
 
     |  let data = XYData()
 
 in cui memorizzare i valori necessari per costruire il grafico.
 
 Dopo basterà inizializzare una variabile di tipo LinePlot con il vettore di tipo xyData.
 
    |  let lineFromDataSet = LinePlot(xyData: data)
 
 Per scegliere il colore della linea si utilizzerà il metodo .color
 
 */


//#-editable-code Inserisci qui il tuo codice
// scrivi qui il tuo codice













//#-end-editable-code


/*
 RIFLESSIONI
 
 - cosa puoi osservare dal grafico ottenuto?
 - la probabilità di trovare due persone con lo stesso compleanno in un gruppo di persone segue l'andamento che avevi previsto?
 - da quante persone deve essere formato il gruppo per vare una probabilità del 99%?
 - possiamo concludere che è bene calcolare sempre la probabilità di un evento perchè NON sempre questa può essere prevista?
 
 
*/



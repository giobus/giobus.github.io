//#-code-completion(module, hide, Swift)
//#-code-completion(identifier, hide, _setup())
//#-code-completion(identifier, hide, AbstractPointChartable)
//#-hidden-code
_setup()

//  Contents.swift
//
//  Copyright (c) 2019 GiovannaBusconi. All Rights Reserved.
//


//: A UIKit based Playground for presenting user interface

import UIKit
import PlaygroundSupport

class MyViewController : UIViewController {
    override func loadView()
    {
        let view = UIView()
        view.backgroundColor = .red
        
        self.view = view
        
        
        //#-end-hidden-code
        
        /*
         
         Supponiamo di avere un gruppo di 10 persone e di voler calcolare la probabilità che due compiano gli anni lo stesso giorno.
         
         La probabilità che la seconda persona NON compia gli anni nello stesso giorno della prima sarà 364/365 perchè andranno bene tutti i giorni tranne uno!
         La probabilità che la terza persona NON compia gli anni nello stesso giorno delle prime due sarà 363/365 perchè saranno due i giorni da evitare!
         ... e così via
         
         Quindi 364/365 * 363/365 * 362/365 *  ... * 356/365 -> è la probabilità che tutte le persone di un gruppo di dieci abbiano compleanni in giorni diversi!
         
         Basterà, quindi, sottrarre questo valore da 1 per avere la probabilità contraria e cioè che due persone su dieci compiano gli anni lo stesso giorno!
         
         Sapresti scrivere il codice che ti permette di calcolare tale valore?
         
         Sapresti fare lo stesso calcolo per 30 persone?
         
         Assegna il risultato dei tuoi calcoli a due variabili di nome prob10 e prob30 (rispettivamente per la probabilità di trovare due con lo stesso compleanno in un gruppo di 10 o di 30 persone)
         
         
         
         */
        var prob10 = 1.0   //dichiarazione e inizializzazione variabile prob10
        var prob30 = 1.0   //dichiarazione e inizializzazione variabile prob30
        //#-editable-code Inserisci qui il tuo codice
        // scrivi qui il tuo codice
        
       
        
        
        
        
        
        
        
       
        
        
       
         //#-end-editable-code
        
       
        
        //#-hidden-code
        
        
        let label = UILabel()
        label.frame = CGRect(x: 50, y: 50, width: 200, height: 40)
        label.text = "   caso: 10 persone"
        label.backgroundColor = .white
        label.textColor = .black
        view.addSubview(label)
        
        let label1 = UILabel()
        label1.frame = CGRect(x: 100, y: 100, width: 200, height: 40)
        label1.text = "   " + String(prob10)
        label1.backgroundColor = .white
        label1.textColor = .black
        view.addSubview(label1)
        
        
        let labeli = UILabel()
        labeli.frame = CGRect(x:0, y: 170, width: 500, height: 1)
        labeli.backgroundColor = .white
        view.addSubview(labeli)
        
        
        let label2 = UILabel()
        label2.frame = CGRect(x: 50, y: 200, width: 200, height: 40)
        label2.text = "   caso: 30 persone"
        label2.backgroundColor = .white
        label2.textColor = .black
        view.addSubview(label2)
        
        let label3 = UILabel()
        label3.frame = CGRect(x: 100, y: 250, width: 200, height: 40)
        label3.text = "   " + String(prob30)
        label3.backgroundColor = .white
        label3.textColor = .black
        view.addSubview(label3)
        
        let labelu = UILabel()
        labelu.frame = CGRect(x:0, y: 320, width: 500, height: 1)
        labelu.backgroundColor = .white
        view.addSubview(labelu)
        
        if (prob10 == 0.1169481777110779) && (prob30 == 0.7063162427192686)
        {
            let label4 = UILabel()
            label4.frame = CGRect(x: 100, y: 400, width: 200, height: 40)
            label4.text = "   Ottimo lavoro!!!"
            label4.textColor = .black
            label4.backgroundColor = .yellow
            view.addSubview(label4)
        } else {
        let label5 = UILabel()
        label5.frame = CGRect(x: 100, y: 400, width: 200, height: 40)
        label5.text = "   Controlla meglio ..."
        label5.textColor = .black
        label5.backgroundColor = .yellow
        view.addSubview(label5)
        }
       
        self.view = view
    }
}
// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()
//#-end-hidden-code


